/*
 * GccApplication1.c
 *
 * Created: 11/28/2020 1:40:57 PM
 * Author : Mehdi Raza Khorasani
 */ 

#include <avr/io.h>
#include <avr/interrupt.h>

int extratime = 0; //counting upto a second
int seconds = 0; 
int minutes = 0; 
int hours; 
void addTime();
ISR(TIMER1_COMPA_vect){//interrupt which updates the state of digital clock
	addTime();
}
int main(void)
{  
	DDRB = 0xFF; //configure port B as output for unit of seconds
	DDRC = 0xFF; //configure port C as output for minutes
	DDRD = 0xFF; //configure port D as output for tens of seconds
	
	OCR1A = 15625; //set the compare match value for the timer
	TCCR1A = 0; TCCR1B = 13;	//CTC mode, prescaler 1024
	TIMSK1 = (1<<OCIE1A);
	sei();
	while(1){} //loop until interrupt arrives	
}
void addTime(){
	if (hours == 24){
		//if 24 hours passed, reset hours
		hours = 0;	}
	if (minutes == 60){
		//check if minutes have moved upto 60: if yes then reset to zero and add 1 to hours
		minutes=0; //reset minutes
		hours++;	}
	if(seconds ==60){
		//check if seconds have moved upto 60: if yes then reset to zero and add 1 to minutes
		seconds = 0; //reset seconds
		minutes++;	}
	else{
		seconds++;	}
	PORTB = seconds%10; //write the value of unit of seconds to PORTB
	PORTC = minutes; //write the value of minutes to PORTC
	PORTD = seconds/10; //write the value of tens of seconds to PORTC
}
